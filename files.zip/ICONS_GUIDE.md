# 📱 Guide de création des icônes PWA

## Structure requise

Crée un dossier `icons/` à la racine du projet avec les fichiers suivants :

```
icons/
├── icon-16.png    (16x16)
├── icon-32.png    (32x32)
├── icon-72.png    (72x72)
├── icon-96.png    (96x96)
├── icon-128.png   (128x128)
├── icon-144.png   (144x144)
├── icon-152.png   (152x152)
├── icon-192.png   (192x192)   ← Obligatoire
├── icon-384.png   (384x384)
└── icon-512.png   (512x512)   ← Obligatoire
```

## Option 1 : Créer ton icône manuellement

### Design recommandé
- **Fond** : Dégradé de #0f172a (bleu foncé) à #1e293b
- **Symbole** : Un appareil photo stylisé ou "HDR" en blanc/cyan (#22d3ee)
- **Style** : Minimaliste, lisible même en petit

### Outils gratuits
1. **Canva** (canva.com) - Templates gratuits
2. **Figma** (figma.com) - Design professionnel
3. **GIMP** - Alternative gratuite à Photoshop

### Étapes
1. Crée ton icône en 512x512 pixels (PNG, fond transparent ou coloré)
2. Utilise un outil de redimensionnement pour créer toutes les tailles

## Option 2 : Générateur automatique (recommandé)

### Étape 1 : Crée une seule image 512x512
Crée `icon-512.png` avec ton design

### Étape 2 : Utilise un générateur en ligne
1. Va sur **realfavicongenerator.net**
2. Upload ton icon-512.png
3. Configure les couleurs (theme: #3b82f6, background: #0f172a)
4. Télécharge le pack complet

### Étape 3 : Alternative - PWA Asset Generator
```bash
# Si tu as Node.js installé
npx pwa-asset-generator icon-512.png icons/ --background "#0f172a" --padding "10%"
```

## Option 3 : Icône temporaire simple

Si tu veux tester rapidement, crée un simple carré avec du texte :

```html
<!-- Génère une icône simple via canvas (à exécuter dans la console navigateur) -->
<script>
function generateIcon(size) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  
  // Fond dégradé
  const gradient = ctx.createLinearGradient(0, 0, size, size);
  gradient.addColorStop(0, '#0f172a');
  gradient.addColorStop(1, '#1e293b');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, size, size);
  
  // Texte HDR
  ctx.fillStyle = '#22d3ee';
  ctx.font = `bold ${size * 0.3}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('HDR', size/2, size/2);
  
  // Télécharger
  const link = document.createElement('a');
  link.download = `icon-${size}.png`;
  link.href = canvas.toDataURL();
  link.click();
}

// Générer toutes les tailles
[16, 32, 72, 96, 128, 144, 152, 192, 384, 512].forEach(generateIcon);
</script>
```

## Vérification

Une fois les icônes créées, vérifie :
1. Ouvre Chrome DevTools > Application > Manifest
2. Tu devrais voir toutes tes icônes listées
3. Teste l'installation sur mobile

## Couleurs de référence

| Élément | Couleur |
|---------|---------|
| Theme color | #3b82f6 (bleu) |
| Background | #0f172a (bleu foncé) |
| Accent | #22d3ee (cyan) |
| Success | #22c55e (vert) |
| Warning | #fbbf24 (jaune) |
